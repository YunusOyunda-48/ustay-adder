-- 3155980's Lua and Manifest Created by Hubcap Manifest
-- Stranded & Naked
-- Created: October 09, 2026 at 11:27:55 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 25832843 (public branch)
-- Build Date: October 09, 2026 at 11:25:41 EDT (1791559541)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3155980) -- Stranded & Naked
-- MAIN APP DEPOTS
addappid(3155981, 1, "ac0f85b7fd3ab5697ec8555ef847654e6abf02e24727d11202a63549398884ff") -- Depot 3155981
setManifestid(3155981, "7041702630639309967", 1732711029)