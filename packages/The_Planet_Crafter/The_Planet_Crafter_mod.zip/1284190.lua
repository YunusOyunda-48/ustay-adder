-- 1284190's Lua and Manifest Created by Hubcap Manifest
-- The Planet Crafter
-- Created: November 04, 2026 at 13:26:11 EST
-- Website: https://hubcapmanifest.com/
-- Build: 26411416 (public branch)
-- Build Date: November 03, 2026 at 12:06:19 EST (1793725579)
-- Total Depots: 1
-- Total DLCs: 2 (1 excluded)

-- MAIN APPLICATION
addappid(1284190, 1, "d691e043b9b43765cb9dce454231965e93fa7fd5b28ca5c6cfb72af0e785adf9") -- The Planet Crafter
-- MAIN APP DEPOTS
addappid(1284192, 1, "1f10eb10bfc54e336b5f2e2a5c05001817700491d0c79a7931637a9158c41dc0") -- Depot 1284192
setManifestid(1284192, "6367121478108035369", 6370896188)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3142540) -- The Planet Crafter - Planet Humble
addappid(4078590) -- The Planet Crafter - Toxicity
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(5478920) -- The Planet Crafter - Magnetaris (unreleased)