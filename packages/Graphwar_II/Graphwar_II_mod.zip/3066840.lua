-- 3066840's Lua and Manifest Created by Hubcap Manifest
-- Graphwar II
-- Created: September 20, 2026 at 15:56:58 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 24996962 (public branch)
-- Build Date: August 28, 2026 at 12:39:01 EDT (1787935141)
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3066840, 1, "feae6f30d054e130a689944bd4ef6060d1391c460810c8a9911edcc5fea5406d") -- Graphwar II
-- MAIN APP DEPOTS
addappid(3066841, 1, "59a7ccbe91b13c99ec47667074882ab10b523d5c5450510e0c2397c63c33586e") -- Depot 3066841
setManifestid(3066841, "8328585593663506219", 104231032)
addappid(3066842, 1, "43e3e7c1a172172dc848a3e844ae238e7db3dd20919bf64cba1361eabde29aba") -- Depot 3066842
setManifestid(3066842, "5762858361338556007", 198315435)
addappid(3066843, 1, "1a1a03c06361ba48c0c2a2ece3c127392e311d73977c6b1563521378c4e492ef") -- Depot 3066843
setManifestid(3066843, "3196255849096228809", 215362590)