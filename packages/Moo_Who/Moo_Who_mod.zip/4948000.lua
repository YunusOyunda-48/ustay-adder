-- 4948000's Lua and Manifest Created by Hubcap Manifest
-- Moo Who?
-- Created: August 26, 2026 at 12:58:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4948000) -- Moo Who?
-- MAIN APP DEPOTS
addappid(4948001, 1, "030610fee4a0d13bbc99e06c4e90d278d6c68c3634a56305e2930c8883c9a63a") -- Depot 4948001
-- setManifestid(4948001, "1768210577221387288", 2034345003)