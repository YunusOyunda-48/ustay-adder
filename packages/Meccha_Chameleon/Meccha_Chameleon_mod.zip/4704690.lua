-- Generated with Luie @ https://lua.tools/
-- 4704690 - MECCHA CHAMELEON
-- Generated 2026-06-30 11:20:29 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(4704690, 1, "ddf5e06be47f8470e5735390673244b191e5ab5562310db7bdbcb539a69a4900")

-- Main Depots
addappid(4704691, 1, "04f85383091217f3b9735b5f34a09e0fbcbcb9afe68e33c25244d37bf45933f8")
setManifestid(4704691, "1098826796124541340", 2597013389)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
