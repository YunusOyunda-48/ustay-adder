-- 2794590's Lua and Manifest Created by Hubcap Manifest
-- Scam Line
-- Created: November 03, 2026 at 14:07:49 EST
-- Website: https://hubcapmanifest.com/
-- Build: 26270927 (public branch)
-- Build Date: October 28, 2026 at 09:01:12 EDT (1793192472)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2794590, 1, "82360d3c52a1b3ff73784f8bf89e3a18370c576b1c5781249852b08e7fb23631") -- Scam Line
-- MAIN APP DEPOTS
addappid(2794591, 1, "51f8d8cb073b66732142b3b3a3effe4a35611fd37f066ac010cce82e62edd0ef") -- Depot 2794591
setManifestid(2794591, "4706979349155224517", 344641578)