-- 4715160's Lua and Manifest Created by Hubcap Manifest
-- Finals Week
-- Created: November 05, 2026 at 13:02:42 EST
-- Website: https://hubcapmanifest.com/
-- Build: 26463516 (public branch)
-- Build Date: November 05, 2026 at 11:38:41 EST (1793896721)
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4715160) -- Finals Week
-- MAIN APP DEPOTS
addappid(4715161, 1, "b7512b76632bd7a88b49f91ec700cb9c9964bc24277a5a2033ada8f25bc7eb48") -- Depot 4715161
setManifestid(4715161, "478376152796061583", 1507688300)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)