-- Forza H​‌‌​​​​‌​‌‌​​​‌‌​​‌‌​​‌​​​‌‌​​‌​​‌‌​​​‌​​​‌‌​‌‌‌​​‌‌​​‌​​​‌‌​​‌​​​‌‌​​​‌​​‌‌​‌‌‌​‌‌​​‌​‌​​‌‌​‌‌‌​​‌‌​‌‌‌​‌‌​​‌‌​​​‌‌‌​​​​‌‌​​‌‌​orizon 6
-- AppID 2483190 | Generated on 2026-05-20 21:10 UTC | openlua.cloud
-- Warning: This game uses DRM (Xbox Live)
-- Note: This game has multiplayer features

-- Main Application
addappid(2483190)
addtoken(2483190, "2264898939686399139")

-- Content Depots (1)
addappid(2483191, 1, "f2a09f0a31b4df681ec0d2d572f368dfa4cd6c37ae67ebdfd591cfbe1334fcd9") -- Forza Horizon 6 - Content

-- Shared Depots (2)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (from 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (from 228980)

-- DLCs without Dedicated Depots (15)
addappid(4562050) -- Forza Horizon 6 Crunchyroll Voucher
addappid(4439300) -- Forza Horizon 6 Ferrari J50
addappid(4439750) -- Forza Horizon 6 Treasure Map
addappid(4439270) -- Forza Horizon 6 Premium VIP
addtoken(4439270, "10281334471861719873")
addappid(4439240) -- Forza Horizon 6 Expansion 1
addtoken(4439240, "10618922691696453695")
addappid(4444140) -- Forza Horizon 6 TBDS2
addappid(4439790) -- Forza Horizon 6 Car Pass
addtoken(4439790, "17274680636771417474")
addappid(4439280) -- Forza Horizon 6 Time Attack Car Pack
addtoken(4439280, "4638210807385755524")
addappid(4439250) -- Forza Horizon 6 Expansion 2
addtoken(4439250, "6382430189070780048")
addappid(4439260) -- Forza Horizon 6 Welcome Pack
addtoken(4439260, "5416694940851378001")
addappid(4444150) -- Forza Horizon 6 1962 Peel P50 Trolli Edition
addappid(4439800) -- Forza Horizon 6 1990 Nissan 12 Skyline GT-R (BNR32 Gr.A) JTC
addtoken(4439800, "17911414783810698062")
addappid(4439290) -- Forza Horizon 6 Italian Passion Car Pack
addtoken(4439290, "7027096395897994901")
addappid(4440380) -- Forza Horizon 6 VIP Membership
addtoken(4440380, "13331842867689162222")
addappid(4520350) -- Forza Horizon 6 Expansions Bundle
addtoken(4520350, "7048682700970800609")
