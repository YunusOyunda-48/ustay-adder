-- 4718490's Lua and Manifest Created by Hubcap Manifest
-- Much Bigger Than my Boyfriend
-- Created: October 09, 2026 at 07:15:53 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 25246690 (public branch)
-- Build Date: September 11, 2026 at 01:56:36 EDT (1789106196)
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4718490) -- Much Bigger Than my Boyfriend
-- MAIN APP DEPOTS
addappid(4718491, 1, "aa9f91cf544bd37f058bdd45681221b35864b242e02d36606f4d3bf7b0145fc7") -- Depot 4718491
setManifestid(4718491, "7936371253984858059", 2747870555)
addappid(4718492, 1, "beefc573db156d43b12e3634d37ed878b47716eb980c4b5697363294067180c3") -- Depot 4718492
setManifestid(4718492, "6668697738505980052", 2736339228)