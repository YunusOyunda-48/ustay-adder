-- 4954910's Lua and Manifest Created by Hubcap Manifest
-- Scam With Your Friends
-- Created: October 18, 2026 at 00:50:20 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 26020526 (public branch)
-- Build Date: October 18, 2026 at 00:17:01 EDT (1792297021)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4954910, 1, "8a9051a93f80aeeefb0ac0e26f3b230f513a03af0a2c27eb898fe2f905451443") -- Scam With Your Friends
-- MAIN APP DEPOTS
addappid(4954911, 1, "5ecd6cfa753bc263676f0dd579968e95d209b1e15363154df11fa51d51d4d94d") -- Depot 4954911
setManifestid(4954911, "2582913840930082535", 4873033994)