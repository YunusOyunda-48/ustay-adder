-- 4285690's Lua and Manifest Created by Hubcap Manifest
-- Airport Security Sucks!
-- Created: June 16, 2026 at 19:57:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4285690, 1, "27d5af42bda4afe5d34d5fabfccd0f5df60ec9e7850a77f5898f5e71cec305a5") -- Airport Security Sucks!
-- MAIN APP DEPOTS
addappid(4285691, 1, "eb7f2322781794e5387ce47e5c1e52ef69cad6de4dc686775446066ef4ab3920") -- Depot 4285691
-- setManifestid(4285691, "7836582520369082099", 3127078607)