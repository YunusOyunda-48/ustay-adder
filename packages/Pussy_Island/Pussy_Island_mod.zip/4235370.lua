-- 4235370's Lua and Manifest Created by Hubcap Manifest
-- Pussy Island
-- Created: October 09, 2026 at 14:14:41 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 25834478 (public branch)
-- Build Date: October 09, 2026 at 12:41:21 EDT (1791564081)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4235370) -- Pussy Island
-- MAIN APP DEPOTS
addappid(4235371, 1, "74d2b47764f05564c78fc79aaf469e5710729a026ae0ecb1e72953bcfc999b9f") -- Depot 4235371
setManifestid(4235371, "4134006853193965727", 1163025355)