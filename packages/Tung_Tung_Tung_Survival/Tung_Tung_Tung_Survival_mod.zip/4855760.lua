-- 4855760's Lua and Manifest Created by Hubcap Manifest
-- Tung Tung Tung Survival
-- Created: October 01, 2026 at 20:37:18 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 25577968 (public branch)
-- Build Date: September 28, 2026 at 08:30:59 EDT (1790598659)
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4855760, 1, "ff4585553d74f8a54832d1b4c03d5bc5c7074bc366540cdbb56bd6d466c78841") -- Tung Tung Tung Survival
-- MAIN APP DEPOTS
addappid(4855761, 1, "befe2b3ce63f7cc66fd6b03e8b98433b0658d5ee7ee28c6dae7ccfceee6a9c91") -- Depot 4855761
setManifestid(4855761, "8928540072598153214", 902420300)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4864670) -- Tung Tung Tung Survival - Supporter Pack