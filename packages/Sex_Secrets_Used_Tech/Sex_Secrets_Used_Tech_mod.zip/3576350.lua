-- 3576350's Lua and Manifest Created by Hubcap Manifest
-- Sex, Secrets & Used Tech
-- Created: September 20, 2026 at 09:38:49 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 24106207 (public branch)
-- Build Date: July 08, 2026 at 05:19:56 EDT (1783502396)
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3576350, 1, "d4bb8b7a72a844686faebb4edc5582ec0c88891db163944a62d6db0b4dab123d") -- Sex, Secrets & Used Tech
-- MAIN APP DEPOTS
addappid(3576351, 1, "a81a90790f79399b98a8563d1cb099b157662333dd4bac8c1a0060086797e56b") -- Depot 3576351
setManifestid(3576351, "1654315165680704507", 2958904176)
-- DLCS WITH DEDICATED DEPOTS
-- Sex, Secrets  Used Tech - Digital Artbook (AppID: 4687240)
addappid(4687240)
addappid(4687240, 1, "744448e72018b51db6274ce8a99abdce9989f5d69f64c6da501a77e970363d7f") -- Sex, Secrets  Used Tech - Digital Artbook - Depot 4687240
setManifestid(4687240, "2351578736436094779", 33748690)