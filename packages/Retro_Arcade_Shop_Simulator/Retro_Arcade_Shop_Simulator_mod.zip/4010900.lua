-- 4010900's Lua and Manifest Created by Hubcap Manifest
-- Retro Arcade Shop Simulator
-- Created: September 04, 2026 at 11:24:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4010900) -- Retro Arcade Shop Simulator
-- MAIN APP DEPOTS
addappid(4010901, 1, "65e710dcf56bf498b324840cadac9010c9692cdcea31e6c7fe5ac7dc9aa11618") -- Depot 4010901
-- setManifestid(4010901, "6120148890557828793", 4270537592)